#!/bin/sh

set -e

if [ "$#" -ne 2 ]; then
  echo "Usage: $0 <temp_dir> <install_dir>"
  exit 1
fi

TEMP_DIR="$1"
INSTALL_DIR="$2"

# Unpack all deb using (ar x) in the temp directory, then extract the
# data.tar.gz from each deb to the chroot directory.
mkdir -p $TEMP_DIR/bash_2.05a-11_i386
ar x "$TEMP_DIR/bash_2.05a-11_i386.deb"               --output "$TEMP_DIR/bash_2.05a-11_i386"
tar -xf "$TEMP_DIR/bash_2.05a-11_i386/data.tar.gz"    -C "$INSTALL_DIR"

mkdir -p $TEMP_DIR/libc6_2.2.5-11.8_i386
ar x "$TEMP_DIR/libc6_2.2.5-11.8_i386.deb"            --output "$TEMP_DIR/libc6_2.2.5-11.8_i386"
tar -xf "$TEMP_DIR/libc6_2.2.5-11.8_i386/data.tar.gz" -C "$INSTALL_DIR"

mkdir -p $TEMP_DIR/libncurses5_5.2.20020112a-7_i386
ar x "$TEMP_DIR/libncurses5_5.2.20020112a-7_i386.deb"            --output "$TEMP_DIR/libncurses5_5.2.20020112a-7_i386"
tar -xf "$TEMP_DIR/libncurses5_5.2.20020112a-7_i386/data.tar.gz" -C "$INSTALL_DIR"

